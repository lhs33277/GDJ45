package parking;

public class ParkingLotMain {

	public static void main(String[] args) {
		ParkingLot pk = new ParkingLot("대박 주차장");
		pk.manage();

	}

}
